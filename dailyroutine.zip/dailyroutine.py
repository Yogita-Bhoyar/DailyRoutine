import datetime
import time

class DailyRoutineReminder:
    def init(self, name):
        self.name = name

    def display_menu(self):
        print(f"Hello, {self.name}!")
        print("1. Set Daily Routine Reminders")
        print("2. View Scheduled Reminders")
        print("3. Start Daily Routine")
        print("4. Exit")

    def set_reminders(self):
        self.reminders = {}
        print("Set your daily routine reminders:")
        self.reminders['Launch'] = input("Enter lunchtime (HH:MM AM/PM): ")
        self.reminders['Sleep'] = input("Enter bedtime (HH:MM AM/PM): ")
        self.reminders['Medicine'] = input("Enter medicine time (HH:MM AM/PM): ")
        self.reminders['Exercise'] = input("Enter exercise time (HH:MM AM/PM): ")
        self.reminders['Health Checkup'] = input("Enter health checkup time (HH:MM AM/PM): ")
        print("Reminders set successfully!")

    def view_reminders(self):
        print("\nYour Scheduled Daily Routine Reminders:")
        for task, time in self.reminders.items():
            print(f"{task}: {time}")

    def start_daily_routine(self):
        current_day = datetime.date.today()
        while True:
            current_time = datetime.datetime.now().strftime("%I:%M %p")
            if current_time in self.reminders.values():
                for task, time in self.reminders.items():
                    if time == current_time:
                        print(f"{task} Reminder: It's {time} - Time for {task}.")
                time.sleep(60)  # Wait for a minute to avoid repeated reminders
            if current_day < datetime.date.today():
                print("Daily routine completed. Goodbye!")
                break

    def run(self):
        while True:
            self.display_menu()
            choice = input("Select an option (1/2/3/4): ")
            if choice == '1':
                self.set_reminders()
            elif choice == '2':
                self.view_reminders()
            elif choice == '3':
                self.start_daily_routine()
            elif choice == '4':
                print("Goodbye!")
                break
            else:
                print("Invalid choice. Please select a valid option.")

if __name__ == "main":
    name = input("Please enter your name: ")
    reminder = DailyRoutineReminder(name)
    reminder.run()